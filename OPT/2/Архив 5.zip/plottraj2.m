function plottraj2(C)
x = C(1,:);
y = C(2,:);
plot(x, y, 'b')
return