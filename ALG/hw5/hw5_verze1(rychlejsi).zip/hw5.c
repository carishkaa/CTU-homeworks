#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "bst.h"

node_t* consolidation(int* nodes_array, int start_index, int last_level, int full_level){
    if (full_level < 1 || (full_level == 1 && last_level == 0))
        return NULL;

    if (full_level == 1 && last_level!=0)
        return new_node(nodes_array[start_index]);

    int left_part = (last_level - full_level/2 >= 0) ? (full_level/2) : (last_level);
    int right_part = last_level - left_part;
    int max_complete_tree = full_level/2 - 1;
    int index = start_index + left_part + max_complete_tree;

    node_t *node = new_node(nodes_array[index]);
    node->left =  consolidation(nodes_array, start_index, left_part, full_level/2);
    node->right = consolidation(nodes_array, index + 1, right_part, full_level/2);
    return node;
} 

int consolidation_count = 0;
int cur_nodes_count = 1;
int depth = 0;

int main(){
    int n;
    scanf("%d", &n);

    // root
    node_t* root = NULL;
    int cur_key;
    scanf("%d", &cur_key);
    root = new_node(cur_key);

    // operations
    for (int i = 1; i < n; i++) {

        scanf("%d", &cur_key);
        _Bool duplicate_key_flag = 0;

        // insert
        if (cur_key > 0){
            int new_depth = -1;
            root = insert(root, cur_key, &duplicate_key_flag, &new_depth);
            if (!duplicate_key_flag) cur_nodes_count++;
            if (depth < new_depth) depth = new_depth;
        }
        // delete
        else {
            root = delete(root, (-1) * cur_key, &duplicate_key_flag);
            if (!duplicate_key_flag) cur_nodes_count--;
            depth = max_depth(root);
        }

        //consolidation
        if (pow(2, depth - 1) > cur_nodes_count){
            consolidation_count++;
            int* nodes_array = (int*) malloc (cur_nodes_count * sizeof(int));
            int ind = 0;
            store_in_order(root, nodes_array, &ind);
            delete_tree(root);

            depth = ceil(log2(cur_nodes_count + 1)) - 1;
            int last_level = cur_nodes_count - pow(2, depth) + 1;
            int max_last_level = pow(2, depth);
            root = consolidation(nodes_array, 0, last_level, max_last_level);

            free(nodes_array);
        }
    }

    printf("%d %d\n", consolidation_count, depth);
    return 0;
}