#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct {
    int cur_days;
    int cur_profit;
    int cur_experiment;
    bool* is_day_used;
} node_t;

typedef struct {
    int active_days_number;
    int* active_days;
    int profit;
} experiment_t;

int max_profit = 0, max_days = 0;
int experiments_number = 0, days_number = 0;

bool fits(int i, int first_day, experiment_t* experiments, node_t node){ // i - № experiment
    int last_day = first_day + experiments[i].active_days[experiments[i].active_days_number - 1];
    if (last_day > days_number - 1){
        return false;
    }
    for (int j = 0; j < experiments[i].active_days_number; j++)
        if (node.is_day_used[first_day + experiments[i].active_days[j]])
            return false;
    return true;
}

void schedule(int i, int first_day, experiment_t* experiments, node_t new_node, node_t node){
    for (int day = 0; day < days_number; day++)
        new_node.is_day_used[day] = node.is_day_used[day];
        
    for (int j = 0; j < experiments[i].active_days_number; j++){
        new_node.is_day_used[first_day + experiments[i].active_days[j]] = true;
    }
}

void foo(node_t node, experiment_t* experiments){
    for (int i = node.cur_experiment; i < experiments_number; i++){
        for (int j = 0; j < days_number; j++){
            if (!node.is_day_used[j] && fits(i, j, experiments, node)){
                // create new node and copy current situation
                node_t new_node;
                new_node.is_day_used = (bool*)malloc(days_number * sizeof(bool));
                schedule(i, j, experiments, new_node, node);
                new_node.cur_profit = node.cur_profit + experiments[i].profit;
                new_node.cur_days = node.cur_days + experiments[i].active_days_number;
                new_node.cur_experiment = i + 1;

                // max profit control
                if (max_profit < new_node.cur_profit || (max_profit == new_node.cur_profit && max_days < new_node.cur_days)){
                    max_profit = new_node.cur_profit;
                    max_days = new_node.cur_days;
                }
                
                // recursion
                foo(new_node, experiments);
                
                free(new_node.is_day_used);
            }
        }
    }
}

int main(){
    //input
    scanf("%d %d", &experiments_number, &days_number);

    experiment_t* experiments = (experiment_t*)malloc(experiments_number * sizeof(experiment_t));
    for (int i = 0; i < experiments_number; i++){
        scanf("%d %d", &experiments[i].active_days_number, &experiments[i].profit);
        experiments[i].active_days = (int*)malloc(days_number * sizeof(int));
        for (int j = 0; j < experiments[i].active_days_number; j++){
            scanf("%d", &experiments[i].active_days[j]);
        }
    }

    node_t root;
    root.is_day_used = (bool*)malloc(days_number * sizeof(bool));
    for (int i = 0; i < days_number; i++)
        root.is_day_used[i] = false;
    root.cur_profit = 0;
    root.cur_days = 0;
    root.cur_experiment = 0;
    
    foo(root, experiments);

    printf("%d %d\n", max_profit, max_days);

    free(root.is_day_used);
    for (int i = 0; i < experiments_number; i++){
        free(experiments[i].active_days);
    }
    free(experiments);

}