#include<stdio.h>
#include<stdlib.h> 
#include<unistd.h> 
#include<sys/types.h> 
#include<sys/wait.h> 
#include <signal.h>

//error checking for system calls
#define try(system_call); if(system_call == -1){ perror("System call error\n"); exit(2); }

static int stop = 0;
void sigterm_handler(int sig){
  stop = 1;
}

int main(){
    pid_t GEN, NSD;
    int pipefd[2];//1 -out , 0 - in 
    try(pipe(pipefd));

    //create processes
    if ((GEN = fork()) > 0)
      NSD = fork();

    //GEN process
    try(GEN);
    if (GEN == 0){
        signal(SIGTERM, sigterm_handler);
        close(pipefd[0]);
        try(dup2(pipefd[1], STDOUT_FILENO));
        close(pipefd[1]);
        while(1){
            if (stop){
                fprintf(stderr, "GEN TERMINATED\n");
                exit(0);
            }
            printf("%d %d\n", rand() % 4096, rand() % 4096);
            fflush(stdout);
            sleep(1);
        }
    }

    //NSD process
    try(NSD);
    if (NSD == 0){
        close(pipefd[1]);
        try(dup2(pipefd[0], STDIN_FILENO));
        close(pipefd[0]);
        try(execl("./nsd", "./nsd", NULL));
    }

    //MAIN
    if (GEN > 0 && NSD > 0){
        close(pipefd[0]);
        close(pipefd[1]);
        sleep(5);

        //terminate GEN and wait
        int status_gen, status_nsd;
        kill(GEN, SIGTERM);
        waitpid(GEN, &status_gen, 0);
        waitpid(NSD, &status_nsd, 0);

        //if the programs ended successfully -> OK, else -> ERROR
        if (WIFEXITED(status_gen) && WIFEXITED(status_nsd) && !WEXITSTATUS(status_gen) && !WEXITSTATUS(status_nsd)){
            printf("OK\n");
            exit(0);
        } else {
            printf("ERROR\n");
            exit(1);
        }
    }

}
